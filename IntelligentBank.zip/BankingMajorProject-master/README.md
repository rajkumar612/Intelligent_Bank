# BankingMajorProject
OCR from scanned PAN Cards, Aaadhar Cards, Bank Cheque books and Sentiment analysis using Machine Learning
